// Bob Dylan
$(document).ready(function () {
    $(".showButton").click(function () {
        $(".BobDylan").toggle();
    });
    $(".showButton").click(function () {
        $(".showButton").hide();
    });
    $(".showButton").click(function () {
        $(".hideButton").show();
    });
    $(".hideButton").click(function () {
        $(".BobDylan").toggle();
    })
    $(".hideButton").click(function () {
        $(".showButton").show();
    });
    $(".hideButton").click(function () {
        $(".hideButton").hide();
    });

    // Will Smith
    $(".buttonShowSmith").click(function () {
        $(".WillSmith").toggle();
    });
    $(".buttonShowSmith").click(function () {
        $(".buttonShowSmith").hide();
    });
    $(".buttonShowSmith").click(function () {
        $(".buttonHideSmith").show();
    });
    $(".buttonHideSmith").click(function () {
        $(".WillSmith").toggle();
    })
    $(".buttonHideSmith").click(function () {
        $(".buttonShowSmith").show();
    });
    $(".buttonHideSmith").click(function () {
        $(".buttonHideSmith").hide();
    });

    // BeeGees
    $(".buttonShowBee").click(function () {
        $(".BeeGees").toggle();
    });
    $(".buttonShowBee").click(function () {
        $(".buttonShowBee").hide();
    });
    $(".buttonShowBee").click(function () {
        $(".buttonHideBee").show();
    });
    $(".buttonHideBee").click(function () {
        $(".BeeGees").toggle();
    })
    $(".buttonHideBee").click(function () {
        $(".buttonShowBee").show();
    });
    $(".buttonHideBee").click(function () {
        $(".buttonHideBee").hide();
    });

    // Kenny Rogers
    $(".buttonShowKenny").click(function () {
        $(".Kenny").toggle();
    });
    $(".buttonShowKenny").click(function () {
        $(".buttonShowKenny").hide();
    });
    $(".buttonShowKenny").click(function () {
        $(".buttonHideKenny").show();
    });
    $(".buttonHideKenny").click(function () {
        $(".Kenny").toggle();
    })
    $(".buttonHideKenny").click(function () {
        $(".buttonShowKenny").show();
    });
    $(".buttonHideKenny").click(function () {
        $(".buttonHideKenny").hide();
    });

});